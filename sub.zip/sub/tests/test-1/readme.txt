1. train a model
1) python main-new.py # please prepare data in the corresponding path


2. evaluation
1) python ../../evaluation.py